opencv_version = "4.5.4.60"
contrib = False
headless = True
ci_build = True